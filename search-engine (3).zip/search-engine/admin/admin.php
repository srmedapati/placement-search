<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title></title>
   <link rel="stylesheet" href="admin.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="css/bootstrap.css">



<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
   <div class="col-6 col-sm-1 col-md-1">
<img src="https://srmap.edu.in/file/2018/03/SRMAP-Logo.png?x34511" class="img-fluid" alt="Responsive image">
</div>

 
<div class="container-fluid">
<div class="row">
     <div class="col-md-3.5 col-sm-4 col-md-offset-3 " style="margin-top:10%;">
       <div class="panel">
       <div class="panel-heading" style="background-color:#999663;"><h4>Placement Search Engine</h4></div>
       <div class="panel-body"> 
   <form method="POST" action="log.php">
    <!--<div class="form-group" style="padding:10px;">-->
      <label for="exampleInputEmail1">Application Number/ Registration Number</label>
      <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="Username" placeholder="Enter Application Number/ Registration Number" required>
    <!--</div>
    <div class="form-group " style="padding:10px;">--->
      <label for="exampleInputPassword1">Password</label>
      <input type="password" class="form-control" id="exampleInputPassword1" name="Password" placeholder="Password">
    <!--</div>

    <div class="text-center" style="margin-top:30px;">-->
    <input type="submit" class="btn btn-success btn-block" name="Login" value="submit" >
    <!--</div>
    <div class="text-center" style="margin-left:200px;margin-top:10px;">-->
    <button type="input" class="btn btn-primary  btn-sm " name="login" value="resetpsd">Forgot password</button>
    <!--</div>-->
</form>




       </div>
     </div>
</div>
</div>
</div>


</body>
</html>

<?php
session_destroy();
?>