<?php
$filename=$_POST['filename'];
$fileext = explode('.',$filename);
$filexten='.'.strtolower(end($fileext));
$destinationfile= $_POST['file_url'];
?>
<html>
<br>

<?php echo "File Name: ".$filename; ?><br>
<?php echo "File Extension: ".$filexten;?><br>
<?php echo "File URL: ".$destinationfile;?><br>
<?php
$var3=$_POST['spl_keys'];
$keywords=explode(',',strtolower($var3));
print_r($keywords);
?>

<br>

<?php
include('connection.php');
mysqli_select_db($con,"sr");
$sql="CREATE TABLE IF NOT EXISTS `keywords`(`id` INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,`keyword` TEXT NOT NULL UNIQUE)";
$result=mysqli_query($con,$sql);
$sql="CREATE TABLE IF NOT EXISTS `file` (`id` INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,`filename` TEXT NOT NULL UNIQUE,`file_url` TEXT NOT NULL UNIQUE,`file_extension` TEXT NOT NULL,`visit_count` INT)";
$result=mysqli_query($con,$sql);
$sql="CREATE TABLE IF NOT EXISTS `log` (`id` INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,`keywordid` INT NOT NULL, `fileid` INT NOT NULL,`categoryid` INT NOT NULL)";
$result=mysqli_query($con,$sql);
$sql="CREATE TABLE IF NOT EXISTS `category` (`categoryid` INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,`category` TEXT NOT NULL UNIQUE)";
$result=mysqli_query($con,$sql);

$category="INSERT IGNORE INTO `category` VALUES ('','$filexten')";
$catresult=mysqli_query($con,$category);
if(!$catresult)
{
    echo "Category ".$filexten." - Error inserting into category Table #Already Present";
}
else{
    echo "Category Insertion Success - ".$filexten;
}
echo "<br>";
$fetchid="SELECT `categoryid` FROM `category` WHERE `category` LIKE '$filexten'";
$fetchkeyid=mysqli_query($con,$fetchid);
$catid=mysqli_fetch_row($fetchkeyid)[0];
echo "<br>Category ID : ",$catid;
?>

<br>

<?php
$fileinsert="INSERT INTO `file` VALUES ('','$filename','$destinationfile','$filexten','0')";
$fileinsertresult=mysqli_query($con,$fileinsert);
if($fileinsertresult)
{
    echo "<br>File data insertion successful <br>";
}
else{
    echo "<br> Error in inserting file data <br> ";
}
$fetchid="SELECT `id` FROM `file` WHERE `filename` LIKE '$filename' AND `file_url` LIKE '$destinationfile'";
$fetchkeyid=mysqli_query($con,$fetchid);
$fileid=mysqli_fetch_row($fetchkeyid)[0];
echo "<br> File exist - File ID : ".$fileid;
?>
<br>
<?php
$keyids=array();
foreach ($keywords as $word) {
    #echo "$word <br>";
    $keywordinsertion="INSERT INTO `keywords` VALUES ('','$word')";
    $keyresult=mysqli_query($con,$keywordinsertion);
    if($keyresult)
    {
        echo "<br> New Keyword Insertion Success - ".$word;
    }
    else{
        echo "<br> Error in inserting keyword - ".$word." #May Already Exist ";
    }

    echo "<br>";
    $fetchid="SELECT `id` FROM `keywords` WHERE `keyword` LIKE '$word'";
    $fetchkeyid=mysqli_query($con,$fetchid);
    array_push($keyids,mysqli_fetch_row($fetchkeyid)[0]);
}
echo "<br>KeyIDs:";
print_r($keyids);
?>

<?php

foreach($keyids as $i){
    $loginput="INSERT INTO `log` VALUES ('','$i','$fileid','$catid')";
    $logresult=mysqli_query($con,$loginput);
    if($logresult)
    {
        echo "<br> Log insertion success ";
    }
    else{
        echo "<br> Error in logging(pair) data ";
    }
}
header("refresh:5;url='crawler.php'");
?>

</html>