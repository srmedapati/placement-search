<?php

$filename=$_POST['filename'];
$fileext = explode('.',$filename);
$filecheck = strtolower(end($fileext));
$destinationfile=$_POST['file_url'];
if(!empty($_POST['youtube'])){
  $checkbox=$_POST['youtube'];
}
else{
  $checkbox=0;
}
?><html> <br>
<?php echo "File Name: ".$filename; ?><br>
<?php echo "File URL: ".$destinationfile;?><br>
<?php
  $var1= $destinationfile;
  $var2=$filename;
  $var3=$_POST['spl_keys'];
  echo "Keywords : ";
  echo $var3."<br>";
  echo $checkbox;
  if($checkbox==1){
    exec("python \"../db/ytdownloader.py\" \"{$var1}\" \"{$var2}\" \"{$var3}\"",$output);
  }
  else{
    exec("python \"../db/downloader.py\" \"{$var1}\" \"{$var2}\" \"{$var3}\"",$output);
  }
  foreach ($output as $statement){
    echo "$statement <br>";
  }
?>
<?php
echo '<script>alert("Added Succesfully")</script>';
sleep(3);
#header("refresh:15;url='crawler.php'");
?>

</html>