<?php
session_start();
if(!isset($_POST['submit']))
{
    echo '<script>alert("Invalid Request")</script>';
    header("refresh:0;url='admin.php'");
}
else
    {
    $Username=$_POST['Username'];
    $Password=$_POST['Password'];
    include('connection.php');
    mysqli_select_db($con,"search");
    
    $sql="SELECT * FROM `login` WHERE `regd_id` = $_POST[Username] AND `pwd` = '$_POST[Password]'";
    $result=mysqli_query($con,$sql);
    if(mysqli_num_rows($result)==1)
    {
        echo '<script>alert("Logged in...! please wait while redirecting to page")</script>';
        $_SESSION['log']=1;
        header("refresh:0;url='crawler.php'");
    }
    else
    {
        echo '<script>alert("Invalid login credentials")</script>';
        $_SESSION['log']=0;
        header("refresh:0;url='admin.php'");
    }
}
?>
