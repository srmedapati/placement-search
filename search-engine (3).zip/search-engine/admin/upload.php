<?php

$file=$_FILES['file'];
$tmpn=$file['name'];
$filename=$_POST['filename'];
$fileerror=$file['error'];
$filetmp=$file['tmp_name'];
$fileext = explode('.',$filename);
$filecheck = strtolower(end($fileext));
$destinationfile='../resources/'.$filename;
move_uploaded_file($filetmp,$destinationfile);

print_r($file);?><html> <br>
<?php echo "File Name: ".$filename; ?><br>
<?php echo "Original Name: ".$tmpn; ?><br>
<?php echo "Error code in uploading: ".$fileerror; ?><br>
<?php echo "Temporary Location: ".$filetmp; ?><br>
<?php echo "Final Location aka File URL: ".$destinationfile;?><br>
<?php
  str_replace("/","//","$destinationfile");
  $var1= $destinationfile;
  $var2=$filename;
  $strkey=$_POST['spl_keys'];
  $var3=$strkey;
  echo "Keywords : ";
  echo $var3;
  exec("python \"../db/basecrawler.py\" \"{$var1}\" \"{$var2}\" \"{$var3}\"",$output);
  foreach ($output as $statement){
    echo "$statement <br>";
  }
?>
<?php
echo '<script>alert("Added Succesfully")</script>';
sleep(10);
#header("refresh:5;url='crawler.php'");
?>

</html>