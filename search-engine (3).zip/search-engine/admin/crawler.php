<?php

?>
<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin.css">
  <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <title>Crawler Page</title>
</head>
<body>
    <div class="col-6 col-sm-1 col-md-1">
        <img src="https://srmap.edu.in/file/2018/03/SRMAP-Logo.png?x34511" class="img-fluid" alt="Responsive image">
    </div>
    <center>
    <div class="container-fluid">
        <div class="row">
        <div class="col-md-4.5 col-sm-6 col-md-offset-2 " style="margin-top:10%; margin-bottom:10%;">
        <div class="panel">
        <div class="panel-heading" style="background-color:#999663;"><h4>Upload File & Crawl</h4></div>
        <div class="panel-body" style="max-height: 200vh;">
                <form action="upload.php" method="POST" enctype="multipart/form-data">
                <div class="form-group" style="padding:10px;">
                    <label for="exampleInputEmail1">File name</label>
                    <input type="text" class="form-control" name="filename" placeholder="Enter File Name" value="" required>
                </div>
                <div class="form-group" style="padding:10px;">
                    <label for="exampleInputEmail1">Upload File</label>
                    <input type="file" class="form-control" name="file" placeholder="Upload here" value="" required>
                </div>
                <div class="form-group" style="padding:10px;">
                            <label for="exampleInputEmail1">Special Keywords</label>
                            <input type="text" class="form-control" name="spl_keys" placeholder="Enter Special Keywords(comma in between)" value="" >
                </div>
                <p>&nbsp;</p>
                <p>
                    <input type="submit" name="Submit" id="Submit" value="Submit" class="btn btn-primary btn-lg btn-block" style="background-color: green";>
                </p>
                <p>
                    <button type="reset" class="btn btn-primary" style="background-color: red;">Reset</button>
                </p>
            </form>
        </div>
</div>
        </div>
        </div>
    </div>
        <div class="container-fluid">
                <div class="row">
                <div class="col-md-4.5 col-sm-6 col-md-offset-3 " style="margin-top:10%;">
                <div class="panel">
                <div class="panel-heading" style="background-color:#999663;"><h4>URL Crawler</h4></div>
                <div class="panel-body" style="max-height: 200vh;">
                        <form action="urlcrawl.php" method="POST">
                        <div class="form-group" style="padding:10px;">
                            <label for="exampleInputEmail1">File name</label>
                            <input type="text" class="form-control" name="filename" placeholder="Enter File Name" value="" required>
                        </div>
                        <!--
                        <p>
                            <label for="mail">Email ID : </label>
                            <input type="text" class="form-control" name="mail" placeholder="Mail ID" value="" required>
                        </p>
                        -->
                        <div class="form-group" style="padding:10px;">
                            <label for="exampleInputEmail1">File URL</label>
                            <input type="text" class="form-control" name="file_url" placeholder="Enter File URL" value="" required>
                        </div>
                        <div class="form-group" style="padding:10px;">
                            <label for="exampleInputEmail1">Special Keywords</label>
                            <input type="text" class="form-control" name="spl_keys" placeholder="Enter Special Keywords(comma in between)" value="">
                        </div>
                        <div class="form-group" style="padding: 10px;">
                            <input type="checkbox" name="youtube" value="1"><label> Video </label></input>
                        </div>
                        <p>&nbsp;</p>
                        <p>
                            <input type="submit" name="Submit" id="Submit" value="Submit" class="btn btn-primary btn-lg btn-block" style="background-color: green;">
                        </p>
                        <p>
                            <button type="reset" class="btn btn-primary" style="background-color: red;">Reset</button>
                        </p>
                    </form>
                </div>
        </div>
                </div>
                </div>
        </div>
        <div class="container-fluid">
                <div class="row">
                <div class="col-md-4.5 col-sm-6 col-md-offset-3 " style="margin-top:10%;">
                <div class="panel">
                <div class="panel-heading" style="background-color:#999663;"><h4>Manual File Indexor</h4></div>
                <div class="panel-body" style="max-height: 200vh;">
                        <form action="manualindex.php" method="POST">
                        <div class="form-group" style="padding:10px;">
                            <label for="exampleInputEmail1">File name</label>
                            <input type="text" class="form-control" name="filename" placeholder="Enter File Name" value="" required>
                        </div>
                        <div class="form-group" style="padding:10px;">
                            <label for="exampleInputEmail1">File URL</label>
                            <input type="text" class="form-control" name="file_url" placeholder="Enter File URL" value="" required>
                        </div>
                        <div class="form-group" style="padding:10px;">
                            <label for="exampleInputEmail1">Special Keywords</label>
                            <input type="text" class="form-control" name="spl_keys" placeholder="Enter Special Keywords(comma in between)" value="">
                        </div>
                        <p>&nbsp;</p>
                        <p>
                            <input type="submit" name="Submit" id="Submit" value="Submit" class="btn btn-primary btn-lg btn-block" style="background-color: green;">
                        </p>
                        <p>
                            <button type="reset" class="btn btn-primary" style="background-color: red;">Reset</button>
                        </p>
                    </form>
                </div>
        </div>
                </div>
                </div>
        </div>
    </center>
</body>
</html>