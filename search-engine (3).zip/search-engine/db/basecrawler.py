#!/usr/bin/env python
import os
import traceback
import txtcrawler
import videocrawl
import pdf
import docs
import excelcrawl
import pptxcrawler
import sys
def fileCrawl(originalurl,file_url,file_name,spl_keystring):
    print(file_url)
    print(spl_keystring)
    file_extension=os.path.splitext(file_name)[1]
    print(file_name)
    print(file_extension)
    spl_keywords=list(spl_keystring.split(","))
    print(spl_keywords)
    if(file_extension=='.txt'):
        text_file=file_url
        txtcrawler.txtcrawl(originalurl,file_url,file_name,text_file,spl_keywords)
    elif(file_extension=='.mp4' or file_extension=='.mkv'):
        OutputFile=r"../temporary_files/temp.txt"
        videocrawl.vidToAudio(originalurl,file_url,file_name,OutputFile,spl_keywords)
    elif(file_extension=='.pdf'):
        OutputFile=r"../temporary_files/temp.txt"
        pdf.pdf2txt(originalurl,file_url,file_name,OutputFile,spl_keywords)
        traceback.print_exc()
    elif(file_extension=='.docx'):
        output_file=r"../temporary_files/temp.txt"
        docs.docxx(originalurl,file_url,file_name,output_file,spl_keywords)
    elif(file_extension=='.xlsx'):
        output_file=r"../temporary_files/temp.txt"
        excelcrawl.xlsxreader(originalurl,file_url,file_name,output_file,spl_keywords)
    elif(file_extension=='.pptx'):
        output_file=r"../temporary_files/temp.txt"
        pptxcrawler.pptxcrawl(originalurl,file_url,file_name,output_file,spl_keywords)

if __name__ == "__main__":
    file_url=sys.argv[1]
    originalurl=file_url
    file_name=sys.argv[2]
    spl_keywords=sys.argv[3]
    fileCrawl(originalurl,file_url,file_name,spl_keywords)

