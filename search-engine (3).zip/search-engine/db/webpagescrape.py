from bs4 import BeautifulSoup
import requests
url="https://pmss.srmap.edu.in/Student/companiescorner.php"
html_file=requests.get(url)
print(html_file)
soup=BeautifulSoup(html_file,'lxml')
print(soup)