import moviepy.editor as mp
import speech_recognition as sr
import txtcrawler
import os
import traceback
from pydub import AudioSegment
from pydub.utils import make_chunks

def vidToAudio(originalurl,file_url,file_name,OutputFile,spl_keywords):
    # Insert Local Video File Path 
    print("Fetching video file")
    clip = mp.VideoFileClip(file_url)
    # Insert Local Audio File Path
    print("Converting to temp audio file")
    file_name_ext= os.path.splitext(file_url)[0]
    audio_file_name=file_name_ext+".wav"
    clip.audio.write_audiofile(audio_file_name)
    clip.close()
    text=" "
    text_file = open(OutputFile,"w+")
    text_file.write(text)
    text_file.close()
    chunks_folder=r"../temporary_files/audio_chunks/"
    chunk(originalurl,file_url,audio_file_name,file_name,OutputFile,spl_keywords,chunks_folder)
    os.remove(audio_file_name)

def chunk(originalurl,file_url,audio_file_name,file_name,OutputFile,spl_keywords,chunks_folder):
    myaudio = AudioSegment.from_file(audio_file_name , "wav") 
    chunk_length_ms = 100000 # pydub calculates in millisec
    chunks = make_chunks(myaudio, chunk_length_ms) #Make chunks of one sec
    #Export all of the individual chunks as wav files
    for i, chunk in enumerate(chunks):
        chunk_name = chunks_folder+"chunk{0}.wav".format(i)
        #print("exporting", chunk_name)
        chunk.export(chunk_name, format="wav")
        speechtoText(originalurl,file_url,chunk_name,file_name,OutputFile,spl_keywords)
        os.remove(chunk_name)
    
    txtcrawler.txtcrawl(originalurl,file_url,file_name,OutputFile,spl_keywords)


def speechtoText(originalurl,file_url,audio_file_name,file_name,OutputFile,spl_keywords):
    r=sr.Recognizer()
    r.energy_threshold = 500
    with sr.AudioFile(audio_file_name) as source:
        print("Listening to audio source")
        audio=r.listen(source)
    try:
        print("Recognizing text")
        text=r.recognize_google(audio)
        print(text)
        text_file = open(OutputFile,"a",encoding="utf8")
        text_file.write(text+"\n\n")
        text_file.close()
    except Exception as e:
        print(e)
