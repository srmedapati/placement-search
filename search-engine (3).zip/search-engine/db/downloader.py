import requests
import basecrawler
import sys
import os

def download_file(url,filename,spl_keystring):
    req = requests.get(url,stream=True)
    try:
        if filename:
            pass
        else:
            filename = req.url[url.rfind('/')+1:]
        with requests.get(url) as req:
            with open("../temporary_files/"+filename, 'wb') as f:
                for chunk in req.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            f.close()
        file_url="../temporary_files/"+filename
        print(file_url)
        basecrawler.fileCrawl(url,file_url,filename,spl_keystring)
        os.remove(file_url)
    except Exception as e:
        print(e)

originalurl=sys.argv[1]
file_name=sys.argv[2]
spl_keywords=sys.argv[3]

download_file(originalurl,file_name,spl_keywords)
