import mariadb 

def init():
    con = mariadb.connect(
    user="root",
    password="",
    host="localhost",
    database="search")
    cur = con.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS keywords (id INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,keyword TEXT NOT NULL UNIQUE)")
    cur.execute("CREATE TABLE IF NOT EXISTS file (id INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,filename TEXT NOT NULL UNIQUE,file_url TEXT NOT NULL UNIQUE,file_extension TEXT NOT NULL,visit_count INT)")
    cur.execute("CREATE TABLE IF NOT EXISTS log (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,keywordid INT NOT NULL, fileid INT NOT NULL,categoryid INT NOT NULL)")
    cur.execute("CREATE TABLE IF NOT EXISTS category (categoryid INT NOT NULL AUTO_INCREMENT UNIQUE,category TEXT NOT NULL UNIQUE)")
    con.commit()
    con.close()

def insertIntokey(l):
    con = mariadb.connect(
    user="root",
    password="",
    host="localhost",
    database="search")
    cur = con.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS keywords (id INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,keyword TEXT NOT NULL UNIQUE)")
    cur.execute("SELECT * FROM keywords")
    for word in l:
        if(word!=" " or word!=""):
            cur.execute("INSERT IGNORE INTO keywords VALUES (?,?)",("",word))
            print("Status : Pass - ",word)
        else:
            print("Status : Fail - ",word)
            continue
        #cur.execute("INSERT IGNORE INTO keywords keyword VALUES (?)",word)
    con.commit()
    con.close()

def insertIntoCategory(file_extension):
    con = mariadb.connect(
    user="root",
    password="",
    host="localhost",
    database="search")
    cur = con.cursor()
    cur.execute('SELECT * from category')
    list=cur.fetchall()
    print(list)
    list_categories=[]
    print(len(list))
    for i in list:
        list_categories.append(i[1])
    print(list_categories)
    if file_extension not in list_categories:
        cur.execute("INSERT INTO category VALUES (?,?)",("",file_extension))
    con.commit()
    con.close()

def insertIntofiles(filename,file_url,file_extension):
    con = mariadb.connect(
    user="root",
    password="",
    host="localhost",
    database="search")
    cur = con.cursor()
    cur.execute("SELECT * from file")
    cur.execute("INSERT INTO file VALUES (?, ?, ?, ?, ?)",('',filename,file_url,file_extension,'0'))
    con.commit()
    con.close()

def insertIntolog(keywords, file_name, file_extension):
    con = mariadb.connect(
    user="root",
    password="",
    host="localhost",
    database="search")
    cur = con.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS log (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,keywordid TEXT NOT NULL, fileid TEXT NOT NULL, categoryid INT NOT NULL)")
    cur.execute('SELECT categoryid from category WHERE category = ?',(file_extension,))
    category_id=cur.fetchall()[0][0]
    print("Category ID:",category_id)
    key_list=[]
    for word in keywords:
        if(word!=" "):
            cur.execute('SELECT id from keywords WHERE keyword = ?',(word,))
            keyword = cur.fetchall()[0][0]
            #print(keyword)
            key_list.append(keyword)
            print("Keyword logged : ",word)
        else:
            print("Keyword eliminated : ",word)
            continue
    key_list.sort()
    print("All keys: ",key_list)
    print(len(key_list))
    cur.execute('SELECT * from file')
    cur.execute("SELECT id FROM file WHERE filename = ?",(file_name,))
    file_id=cur.fetchall()[0][0]
    print("File_id: ",file_id)
    print("\n\n\n")
    cur.execute('SELECT * from log')
    for i in key_list:
        cur.execute("INSERT INTO log VALUES (?, ?, ?, ?)", ("" ,i, file_id,category_id))
    # for word in key:
    #     cur.execute("INSERT INTO log VALUES (?, ?)", word, file)
    con.commit()
    con.close()

def erase():
    con = mariadb.connect(
    user="root",
    password="",
    host="localhost",
    database="search")
    cur = con.cursor()
    cur.execute("DROP TABLE keywords")
    cur.execute("DROP TABLE file")
    cur.execute("DROP TABLE log")
    con.commit()
def insert(l):
    con = mariadb.connect(
    user="root",
    password="",
    host="localhost",
    database="search")
    cur = con.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS trail (msg1 TEXT NOT NULL,msg2 TEXT NOT NULL UNIQUE)")
    cur.execute("INSERT INTO trail VALUES (?, ?)", l)
    con.commit()
    read(cur)

def read(cur):
    cur.execute('SELECT * from trail')

