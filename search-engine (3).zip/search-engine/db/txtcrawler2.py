#!/usr/bin/env python

#txtcrawl(originalurl,file_url,filename,text_file,spl_keywords)
import spacy
import os
from nltk.util import pr
nlp = spacy.load("en_core_sci_lg",disable="ner")

def textract(doc):
    list=[]
    for _ in doc:
        if _.pos_ in ["NOUN","PRON","VERB"] and _.dep_ in ["dobj","ROOT","compound"]:
            list.append(_)
    return list

def txtcrawl(filename,text_file):
    #nlp = spacy.load("en_core_sci_sm")
    file_extension=os.path.splitext(filename)[1]
    print("Opening text file...!")
    sample_file = open(text_file,encoding="utf8")
    print("Reading text file..!")
    text = sample_file.read()
    print(text)
    sample_file.flush()
    print("Analyzing..!")
    doc=nlp(text)
    print("\n",set(textract(doc)))
    types=[]
    dep=[]
    #doc for doc in nlp.pipe(text) if textract(doc)
    """
    for _ in doc:
        if _.pos_ in ["NOUN","PRON"]: #and _.dep_ in ["dobj","ROOT","compound"]:
            print(_,"-",_.pos_,"-",_.dep_,"\n")
            #types.append(_.pos_)
            dep.append(_.dep_)
    #types=set([_.pos_ for _ in doc])
    #print(set(types))
    
    print(set(dep))
    #for i in set(types):
    #    print(i,"-",spacy.explain(str(i)),"\n")
    for i in set(dep):
        print(i,"-",spacy.explain(str(i)),"\n")
    """
filename="FreeGuy.txt"
text_file=r"C:/Users/Raghuveer199/Desktop/FreeGuy.txt"
txtcrawl(filename,text_file)