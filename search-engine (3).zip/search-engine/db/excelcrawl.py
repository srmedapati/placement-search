def xlsxreader(originalurl,file_url,file_name,output_file,spl_keywords):
    import pandas as pd
    import txtcrawler
    df=pd.ExcelFile(file_url)
    sheet_list=df.sheet_names
    keywords=[]
    for i in sheet_list:
        print(i)
        cols=[]
        rows=[]
        f=df.parse(sheet_name=i,header=None,nrows=10)
        print(type(f))
        print(f)
        for col in f.columns:
            cols.append(col)
        print("Columns:",cols)
        for row in f.index:
            rows.append(row)
        print("Rows:",rows)
        for i in cols:
            print("\n")
            for j in rows:
                if(str(f.loc[j,i])!= 'nan'):
                    keywords.append(str(f.loc[j,i]))
                    print(f.loc[j,i])
                    #break;
    print(keywords)
    set(keywords)
    list(keywords)
    spl_keywords=spl_keywords+keywords
    with open(output_file,'w') as f:
        f.write("")
    f.close
    text_file=output_file
    #originalurl=file_url
    txtcrawler.txtcrawl(originalurl,file_url,file_name,text_file,spl_keywords)
    
#output_file=r"./temporary_files/temp.txt"
#xlsxreader(r"C:\Users\Raghuveer199\Downloads\Internship Mentors Assignment Approved List 15-06-2021 .xlsx",r"Excel_file1.xlsx",output_file,[])