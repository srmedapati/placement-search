from pptx import Presentation
import txtcrawler

def pptxcrawl(originalurl,file_url,file_name,output_file,spl_keywords):
    prs = Presentation(file_url)
    text_runs = []
    slide_count=0
    for slide in prs.slides:
        slide_count=slide_count+1
    print(slide_count)
    if(slide_count<20):
        x=slide_count
    else:
        x=20
    for i in range(x):
        slide=prs.slides[i]
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            for paragraph in shape.text_frame.paragraphs:
                for run in paragraph.runs:
                    text_runs.append(run.text)
    print(text_runs)
    with open(output_file,'w',encoding="utf8") as f:
        for i in text_runs:
            f.write(i+"\n")
    f.close
    txtcrawler.txtcrawl(originalurl,file_url,file_name,output_file,spl_keywords)

#file_url=r"C:\Users\Raghuveer199\Downloads\MEDICINE SHORTAGE-308-CSE-MRMSRReddy.pptx"
#originalurl=file_url
#file_name=r"IDEA_4_360.pptx"
#output_file=r"./temporary_files/temp.txt"
#spl_keywords=[]
#pptxcrawl(originalurl,file_url,file_name,output_file,spl_keywords)
