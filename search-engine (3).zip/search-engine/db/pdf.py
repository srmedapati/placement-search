#!/usr/bin/env python
import fitz
import txtcrawler

def pdf2txt(originalurl,file_url,file_name,OutputFile,spl_keywords):
    fname = file_url  # get document filename
    doc = fitz.open(fname)  # open document
    print("Number of Pages: ",doc.pageCount)
    if(doc.pageCount<10):
        pagescanlimit=doc.pageCount
    else:
        pagescanlimit=min(15,doc.pageCount)
    print("Page Scan Limit : ",pagescanlimit)
    with open(OutputFile,"w+",encoding="utf-8") as out:# open text output
        print("Text File opened")
        for i in range(0,pagescanlimit):  # iterate the document pages
            page=doc[i]
            print("Scanning Page ",i)
            text = page.get_text()# get plain text (is in UTF-8)
            print("Text extracted from page",i)
            print(text)
            out.write(text)  # write text of page
            print("Writing to text file",OutputFile)
        out.flush()
    doc.close()
    txtcrawler.txtcrawl(originalurl,file_url,file_name,OutputFile,spl_keywords)
