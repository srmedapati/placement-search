#!/usr/bin/env python
import spacy
import os
import sqlitehelper as helper
import re
def textract(doc):
    list=[]
    for _ in doc:
        word=re.sub(r"[^a-z0-9']+", ' ', str(_).lower())
        word=word.split()
        for i in word:
            if len(i)>=5:
                list.append(i)
    return list

def txtcrawl(originalurl,file_url,filename,text_file,spl_keywords):
    
    nlp = spacy.load("en_core_sci_lg")
    sample_file = open(text_file,encoding="utf8")
    print(sample_file)
    text = sample_file.read()
    sample_file.flush()
    doc = nlp(text)
    keywords=textract(doc.ents)+[os.path.splitext(filename)[1].lower(),filename.lower()]
    print(keywords)
    print("Total Keywords: ",len(keywords))
    print(keywords)
    print("File Name : ",filename)
    print("File Extension : ",os.path.splitext(filename)[1].lower())
    print("URL : ",originalurl)