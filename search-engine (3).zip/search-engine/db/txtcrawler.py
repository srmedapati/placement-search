#!/usr/bin/env python

def txtcrawl(originalurl,file_url,filename,text_file,spl_keywords):
    import spacy
    import os
    import sqlitehelper as helper
    import re
    #nlp = spacy.load("en_core_sci_sm")
    nlp = spacy.load("en_core_sci_lg")
    print("Opening text file...!")
    sample_file = open(text_file,encoding="utf8")
    print(sample_file)
    print("Reading text file..!")
    text = sample_file.read()
    sample_file.flush()
    print("Analyzing..!")
    doc = nlp(text)
    file_extension=os.path.splitext(filename)[1]
    keywords=[]
    bad_chars = [';', ':', '!', "*",'#',"\n","&","^","'s","'ll","'d","'re","•"]
    for i in doc.ents:
        string_word=str(i).lower()
        string_word = ''.join(i for i in string_word if not i in bad_chars)
        keywords.append(string_word)
    keywords.append(os.path.splitext(filename)[0])
    final_keys=[]
    file_name_keys=os.path.splitext(filename)[0].split()
    keywords=keywords+spl_keywords+ file_name_keys
    for word in keywords:
        word=word.lower()
        final_keys.append(word)
    final_keys=set(final_keys)
    finalizing_keys=[]
    for i in final_keys:
        only_alpha = ""
        for char in i:
            if ord(char) >= 43 and ord(char) <= 125:
                only_alpha += char
            ## checking for lower case
            elif ord(char) == 32:
                only_alpha += char
            else:
                continue
        alpha=re.sub(' +', ' ',only_alpha)
        finalizing_keys.append(alpha)
    print("Total Keywords: ",len(finalizing_keys))
    print(finalizing_keys)
    print("File Name : ",filename)
    print("File Extension : ",file_extension)
    print("URL : ",originalurl)
    helper.init()
    helper.insertIntofiles(filename,originalurl,file_extension)
    helper.insertIntoCategory(file_extension)
    helper.insertIntokey(finalizing_keys)
    helper.insertIntolog(finalizing_keys,filename,file_extension)
