def docxx(originalurl,file_url,file_name,text_file,spl_keywords):
    import docx2txt
    import txtcrawler
    # extract text
    text = docx2txt.process(file_url)
    with open(text_file,'w+',encoding="utf-8") as f:
        f.write(text)
    f.close()
    txtcrawler.txtcrawl(originalurl,file_url,file_name,text_file,spl_keywords)
