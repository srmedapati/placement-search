from youtube_dl import YoutubeDL
import basecrawler
import os
import sys

def video_download(url,filename,spl_keystring):
    ydl_opts = {
    'format': 'best',
    'outtmpl': '../temporary_files/'+filename,
    'noplaylist': True,
    'extract-audio': True,
    }
    video = url
    with YoutubeDL(ydl_opts) as ydl:
        info_dict = ydl.extract_info(video, download=True)
        video_url = info_dict.get("url", None)
        video_id = info_dict.get("id", None)
        video_title = info_dict.get('title', None)
        video_length = info_dict.get('duration')
    print("Video Duration : ",video_length)
    file_url="../temporary_files/"+filename
    print(file_url)
    basecrawler.fileCrawl(url,file_url,filename,spl_keystring)
    try:
        os.remove(file_url)
    except Exception as e:
        print(e)


originalurl=sys.argv[1]
file_name=sys.argv[2]
spl_keywords=sys.argv[3]
video_download(originalurl,file_name,spl_keywords)
