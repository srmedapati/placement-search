<?php
$keywordOriginal=$_GET['keyword'];
$keyword=trim($keywordOriginal);
$str2Array=explode(" ",strtolower($keyword));
array_push($str2Array,$keywordOriginal);
$strArray=array_unique($str2Array,SORT_STRING);
?>

<html>

<head>
    <title>Search</title>
    <link rel="shortcut icon" type="image/ico" href="srmap.png" />
    <link rel="stylesheet" href="./search.css" />
</head>

<body><header>
    <section id="header">
        <div id="topbar">
            <img id="searchbarimage" src="srmaplogo.png" />
            <form action="search.php">
                <input id="searchbartext" type="text" value="<?php if(isset($_GET["keyword"])) echo $_GET["keyword"]; ?>" name="keyword" />
            </form>
            </div>
        </div>
</section>

</header>

        <section id="optionsbar">
            <ul id="optionsmenu1">
                <li><a href="search.php?keyword=<?PHP echo $keyword; ?>">All</li>
                <li id="optionsmenuactive"><a href="sheets.php?keyword=<?PHP echo $keyword; ?>">Sheets</li>
                <li><a href="video.php?keyword=<?PHP echo $keyword; ?>">Videos</li>
                <li><a href="pdf.php?keyword=<?PHP echo $keyword; ?>">PDF</li>
                <li><a href="docs.php?keyword=<?php echo $keyword?>">Docs</li>
                <li><a href="#"> </li>
            </ul>
        </section>
        <br>

    <main>
    <div class="retrieved">
        <?php
        $servername="localhost";
        $username="root";
        $password="";
        $dbname="search";
        session_start();
            $con= mysqli_connect($servername,$username,$password,$dbname) or die('could not connect:'.mysqli_error($con));
            mysqli_select_db($con,"search");
            $keywordid_array=array();
            $catsql="SELECT `categoryid` FROM `category` WHERE `category` LIKE '.xlsx'";
            $catquery=mysqli_query($con,$catsql);
            $catresult=mysqli_fetch_assoc($catquery);
            $catid=$catresult['categoryid'];
            #function to fetch keyword and pattern match keyword ids
            $files=array();
            function keyidfetch($word,$con,$keywordid_array) {
                $sql="SELECT `id` FROM `keywords` WHERE `keyword` LIKE '$word'";
                $query=mysqli_query($con,$sql);
                $result=mysqli_fetch_assoc($query);
                if($result){
                    array_push($keywordid_array,$result['id']);
                    $len=strlen($word);
                    if($len>=6){
                        $subkey=substr($word,0,$len/2);
                        $sql="SELECT `id` FROM `keywords` WHERE `keyword` REGEXP '$subkey'";
                        $query=mysqli_query($con,$sql);
                        while($result=mysqli_fetch_assoc($query)){
                        array_push($keywordid_array,$result['id']);
                }}}
                $keywordid_array=array_unique($keywordid_array,SORT_STRING);
                return $keywordid_array;
            }

            #KeyIDs for all keywords entered in
            $keywordsrelate=array();
            foreach($strArray as $word){
                $keyarray=keyidfetch($word,$con,$keywordid_array);
                $keywordsrelate = array_merge($keywordsrelate,$keyarray);
            }
            #print_r($keywordsrelate);

            #Get linked data from log file
            foreach($keywordsrelate as $keyid){
                #echo "Keyword ID : ".$keyid."<br>";
                $sql_log="SELECT * FROM `log` WHERE `keywordid`='$keyid' AND `categoryid`='$catid'";
                $log_query=mysqli_query($con,$sql_log);
                while($res=mysqli_fetch_array($log_query)){
                    $file_name_id=$res['fileid'];
                    #Fetch file IDs,Visit Count using fileIDs from 'log' file
                    $sql_file="SELECT `id`,`visit_count` FROM `file` WHERE `id` LIKE '$file_name_id'";
                    $file_query=mysqli_query($con,$sql_file);
                    if($file_query){
                        $res_final=mysqli_fetch_assoc($file_query);
                        if(array_key_exists($res_final['id'],$files)){
                            #echo "<br> File Id :".$res_final['id']."<br>";
                            $multi_key=$files[$res_final['id']];
                            $multi_key[1]=$multi_key[1]+1;
                            $files[$res_final['id']]=array($res_final['visit_count'],$multi_key[1]);
                            #echo $multi_key[1]."<br>";
                        }
                        else{
                            #echo "<br> File Id :".$res_final['id']."<br>";
                            $files[$res_final['id']]=array($res_final['visit_count'],0);
                            $multi_key=$files[$res_final['id']];
                            #echo $multi_key[1]."<br>";
                            #print_r($multi_key);
                        }
                    }
                }
            }
                foreach($files as $file_id => $filecount_value){
                    $sort_value=0;
                    #echo "File ID : ".$file_id."<br>";
                    $multi_key=$files[$file_id];
                    #echo $multi_key[0];
                    #echo $multi_key[1]."<br>";
                    $sort_value=($multi_key[1]*10)+$multi_key[0];
                    #echo $sort_value."<br>";
                    $sorted_file_list[$file_id]=$sort_value;
                }
            #print_r($sorted_file_list);
            arsort($sorted_file_list);
            #print_r($sorted_file_list);
                #echo "<br>";
                #Fetch data from 'file' using file IDS
                foreach($sorted_file_list as $file_id => $filecount_value){
                    $sql_file="SELECT * FROM `file` WHERE `id` LIKE '$file_id'";
                    $file_query=mysqli_query($con,$sql_file);
                    if($file_query){
                    while($res_final=mysqli_fetch_array($file_query)){ 
                        ?>
                        <table>
                        <tr>
                        <p class="fileid"><?php echo "File ID : ".$res_final['id']; ?></p>
                        <p class="filename"><?php echo "File Name : ".$res_final['filename'];?></p>
                        <p class="file_url"  onclick= "myFunction('<?php echo $res_final['id']; ?>','<?php echo $res_final['file_url']; ?>')" > <?php echo $res_final['file_url'] ?></p>
                        <p class="views"><?php echo "Visit Count : ".$res_final['visit_count'];?></p>
                        <hr>
                        </tr>
                        </table>
                    <?php
                }}}
                ?>
            </div>
        </main>
</body>
<script>
    function myFunction($fileid,$file_url) {
        //var httpc = new XMLHttpRequest(); // simplified for clarity
        var url = "./updatecount.php?id="+$fileid+"&url="+$file_url;
        console.log(url);
        window.open(url,$file_url);
        var url= $file_url;
        console.log(url);
    }
</script>
</html>