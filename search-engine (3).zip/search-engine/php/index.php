
<html>
<head>
<title>search</title>
<link rel ="stylesheet" href="style.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="UTF-8">
<link rel="stylesheet" href="style.css">
<link rel ="icon" href="srmap.png">


</head>
<body>
<div class ="main">
    <img src="srmaplogo.png"><br>
    <div><p><br></p></div>
    <div class="searchBox">
        <form action="search.php">
            <input type="text" name="keyword" placeholder="Enter keyword...! " required class ="search">
        </form>
    </div> 


</div>
</body>


</html>



