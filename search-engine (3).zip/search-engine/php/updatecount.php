<?php
$id=$_GET['id'];
echo $id;
$fileurl=$_GET['url'];
echo $fileurl;
$conn = mysqli_connect('localhost', 'root', '','search');

if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}
// Perform query
if ($result = mysqli_query($conn, "UPDATE `file` SET `visit_count`=`visit_count`+1 WHERE `id`= '$id'")) {	
}
mysqli_close($conn);
header("refresh:0;url= $fileurl");
?>